Red Lark Workshop local type kit.
Bebas Neue / IBM Plex Mono / Noto Sans Devanagari, Bengali and Malayalam. Original upstream fonts, not CC0 artwork.
Each retains its SIL Open Font Licence. Read before redistribution. Indic source provenance is included.
Sources: https://github.com/google/fonts/tree/main/ofl/bebasneue
https://github.com/google/fonts/tree/main/ofl/ibmplexmono
