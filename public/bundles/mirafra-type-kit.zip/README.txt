Mirafra local type kit.
Bebas Neue / IBM Plex Mono. Original upstream fonts, not CC0 artwork.
Both retain their SIL Open Font Licence files. Read them before redistribution.
Sources: https://github.com/google/fonts/tree/main/ofl/bebasneue
https://github.com/google/fonts/tree/main/ofl/ibmplexmono
